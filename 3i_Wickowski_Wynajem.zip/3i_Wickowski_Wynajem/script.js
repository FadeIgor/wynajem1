const liczba_dni = Number(prompt('Podaj liczbe dni'));

if (isNaN(liczba_dni) || liczba_dni <= 0) {
    alert("Proszę podać prawidłową liczbę dni.");
}

let rabat = 50 * Math.trunc(liczba_dni / 7);

function rentCost(days) {
    let x = 1;
    if (days === 1) x = 200;
    else if (days === 3 || days === 2) x = 180 * days;
    else if (days >= 4 && days <= 7) x = 160 * days;
    else if (days >= 8) x = 150 * days;
    else alert("Wartość niepoprawna");

    if (days >= 7) x = x - rabat;
    return x;
}

document.write("Cena za wynajem pokoju na ", liczba_dni, " dni wynosi: ", rentCost(liczba_dni), "zł, w tym rabat: ", rabat,"zł");
